package net.ahmed.universitymanagement.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.Date;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Absence {
    @Id
    @UuidGenerator
    private String id;

    @ManyToOne
    private Matiere matiere;

    @ManyToOne
    private Student student;

    @Temporal(TemporalType.DATE)
    private Date date;
    
    private int nha;
}