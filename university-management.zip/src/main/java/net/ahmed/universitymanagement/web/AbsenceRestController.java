package net.ahmed.universitymanagement.web;


import net.ahmed.universitymanagement.entities.Absence;
import net.ahmed.universitymanagement.repositories.AbsenceRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")

public class AbsenceRestController {
    private final AbsenceRepository absenceRepository;

    public AbsenceRestController(AbsenceRepository absenceRepository) {
        this.absenceRepository = absenceRepository;
    }
    @GetMapping("/absences")
    public List<Absence> getAllAbsences() {
        return absenceRepository.findAll();
    }
    @GetMapping("/absences/{uuid}")
    public Absence getAbsenceById(@PathVariable("uuid") String uuid) {
        if (absenceRepository.findById(uuid).isPresent()) {
            return absenceRepository.findById(uuid).get();
        } else {
            return null;
        }
    }
    @PostMapping(value = "/absences/create", consumes = "application/json", produces = "application/json")
    public Absence createAbsence(@RequestBody Absence newAbsence) {

        return absenceRepository.save(newAbsence);
    }
    @PutMapping("/absences/{uuid}")
    public Absence updateAbsence(@PathVariable("uuid") String uuid, @RequestBody Absence newAbsence) {
        if (absenceRepository.findById(uuid).isPresent()) {
            Absence existingAbsence = absenceRepository.findById(uuid).get();
            existingAbsence.setStudent(newAbsence.getStudent());
            existingAbsence.setMatiere(newAbsence.getMatiere());
            existingAbsence.setNha(newAbsence.getNha());
            existingAbsence.setDate(newAbsence.getDate());

            return absenceRepository.save(existingAbsence);
        } else {
            return null;
        }
    }

    @DeleteMapping("/absences/{uuid}")
    public String deleteAbsence(@PathVariable("uuid") String uuid) {
        if (absenceRepository.findById(uuid).isPresent()) {
            absenceRepository.deleteById(uuid);
            return "Absence with id " + uuid + " is deleted";
        } else {
            return "Error! Absence not found";
        }
    }

    @GetMapping("/absences/student/{uuid}")
    public List<Absence> getAbsencesByStudentId(@PathVariable("uuid") String uuid) {
        return absenceRepository.findByStudentId(uuid);
    }






}
