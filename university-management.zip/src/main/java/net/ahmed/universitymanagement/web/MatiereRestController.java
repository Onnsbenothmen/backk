package net.ahmed.universitymanagement.web;

import net.ahmed.universitymanagement.entities.Matiere;
import net.ahmed.universitymanagement.repositories.MatiereRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class MatiereRestController {
    private final MatiereRepository matiereRepository;

    public MatiereRestController(MatiereRepository matiereRepository) {
        this.matiereRepository = matiereRepository;
    }

    @GetMapping("/matieres")
    public List<Matiere> getAllMatieres() {
        return matiereRepository.findAll();
    }

    @GetMapping("/matieres/{uuid}")
    public Matiere getMatiereById(@PathVariable("uuid") String uuid) {
        if (matiereRepository.findById(uuid).isPresent()) {
            return matiereRepository.findById(uuid).get();
        } else {
            return null;
        }
    }

    @PostMapping(value = "/matieres/create", consumes = "application/json", produces = "application/json")

    public Matiere createMatiere(@RequestBody Matiere newMatiere) {
        Matiere matiere = Matiere.builder()
                .name(newMatiere.getName())
                .build();

        return matiereRepository.save(newMatiere);
    }

    @PutMapping("/matieres/{uuid}")
    public Matiere updateMatiere(@PathVariable("uuid") String uuid, @RequestBody Matiere newMatiere) {
        if (matiereRepository.findById(uuid).isPresent()) {
            Matiere existingMatiere = matiereRepository.findById(uuid).get();
            existingMatiere.setName(newMatiere.getName());


            return matiereRepository.save(existingMatiere);
        } else {
            return null;
        }
    }

    @DeleteMapping("/matieres/{uuid}")
    public String deleteMatiere(@PathVariable("uuid") String uuid) {
        if (matiereRepository.findById(uuid).isPresent()) {
            matiereRepository.deleteById(uuid);
            return "Matiere deleted successfully";
        } else {
            return null;
        }
    }


}


