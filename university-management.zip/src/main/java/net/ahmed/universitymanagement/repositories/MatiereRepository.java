package net.ahmed.universitymanagement.repositories;

import net.ahmed.universitymanagement.entities.Matiere;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatiereRepository extends JpaRepository<Matiere, String> {
}
