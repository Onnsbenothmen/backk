package net.ahmed.universitymanagement.repositories;

import net.ahmed.universitymanagement.entities.Absence;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AbsenceRepository extends JpaRepository<Absence, String> {
    List<Absence> findByStudentId(String uuid);
}
